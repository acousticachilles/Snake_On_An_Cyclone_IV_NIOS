/*
 * type.h
 *
 *  Created on: 2014-2-13
 *      Author: Administrator
 */

#ifndef TYPE_H_
#define TYPE_H_

typedef unsigned char uchar;
typedef unsigned int  uint;
typedef unsigned char u8;
typedef unsigned int  u16;
typedef unsigned long u32;

#endif /* TYPE_H_ */
