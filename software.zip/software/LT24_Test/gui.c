// ============================================================================
// Copyright (c) 2014 by Terasic Technologies Inc.
// ============================================================================
//
// Permission:
//
//   Terasic grants permission to use and modify this code for use
//   in synthesis for all Terasic Development Boards and Altera Development
//   Kits made by Terasic.  Other use of this code, including the selling
//   ,duplication, or modification of any portion is strictly prohibited.
//
// Disclaimer:
//
//   This VHDL/Verilog or C/C++ source code is intended as a design reference
//   which illustrates how these types of functions can be implemented.
//   It is the user's responsibility to verify their design for
//   consistency and functionality through the use of formal
//   verification methods.  Terasic provides no warranty regarding the use
//   or functionality of this code.
//
// ============================================================================
//
//  Terasic Technologies Inc
//  9F., No.176, Sec.2, Gongdao 5th Rd, East Dist, Hsinchu City, 30070. Taiwan
//
//
//                     web: http://www.terasic.com/
//                     email: support@terasic.com
//
// ============================================================================

#include "terasic_includes.h"
#include "gui.h"
#include "alt_video_display.h"
#include "simple_graphics.h"
#include "geometry.h"
#include "touch_spi.h"
#include <stdlib.h>


//#define DOT_SIZE    10
#define X_WIDTH 	22
#define Y_HEIGHT	21


//void GUI_ShowInfo(alt_video_display *pDisplay, char *pText);
void GUI_ShowWelcome(alt_video_display *pDisplay);
//void GUI_ShowTouchPoint(alt_video_display *pDisplay, int X1, int Y1, int color);
//void VPG_Grida(alt_video_display *pDisplay);
void paint_Cell(int head_X, int head_Y, alt_video_display *pDisplay);
void clear_Cell(int head_X, int head_Y, alt_video_display *pDisplay);
void paint_Food(int food_X, int food_Y, alt_video_display *pDisplay);
void reset( int *array, int size);
//int set_X(int gridFill_X[], int snakeSize);
//int set_Y(int gridFill_Y[], int snakeSize);

alt_u32 szPalette[] = {
    BLUE_24,
    BLUE_24,
    BLUE_24,
    BLUE_24,
    BLUE_24
};



typedef struct{
	int head_X;
	int head_Y;
}HEAD_LOCATION;


typedef enum{
    BTN_ONE = 0,
    BTN_TWO,
    BTN_THREE,
    BTN_FOUR,
    BTN_FIVE,
    BTN_SIX,
    BTN_SEVEN,
    BTN_NUM,
    BTN_NONE
}BUTTON_ID;

typedef enum {RIGHT, LEFT, UP, DOWN} DIRECTION;

typedef	struct {
	int food_X;
	int food_Y;
}FOOD_LOCATION;

typedef struct{
    RECT rc;
    int  color;
}PALETTE_INFO;

typedef struct{
    int Paint_Index;
    RECT rcPaint;
    PALETTE_INFO szPalette[BTN_NUM];
}DESK_INFO;







void GUI_ShowWelcome(alt_video_display *pDisplay){
	int x, y;


	x = pDisplay->width / 2 - 60;
	y = pDisplay->height / 2 - 10;

	vid_clean_screen(pDisplay, BLACK_24);
	vid_print_string_alpha(x - 30, y, BLUE_24, BLACK_24, tahomabold_20, pDisplay, "Hey man...");
	usleep(1*1000*1000);
	vid_clean_screen(pDisplay, BLACK_24);
	vid_print_string_alpha(x - 30, y, BLUE_24,BLACK_24, tahomabold_20, pDisplay, "don't eat yourself");
	usleep(1*1000*1000);
	vid_clean_screen(pDisplay, BLACK_24);

}

//start setupping up screen items,
void GUI_DeskInit(alt_video_display *pDisplay, DESK_INFO *pDeskInfo){
    int i;
    RECT rc;
    RECT rcScreen;
    const int BoxH = 40;
    const int BoxW = 40;
    const int GapH = 5;
    const int DrawBorder = 2;
//    const int TextW = 0;
//    const int ClearExtraW = 0;
    int GapW;

    //set dimensions to the buttons
    GapW = (pDisplay->width - ((BTN_NUM - 3)*BoxW))/((BTN_NUM - 3)+1);
    //printf("GapW=%d\r\n", GapW);
    rc.top = pDisplay->height - BoxH - GapH;
    rc.bottom = rc.top + BoxH;
    rc.left = GapW;
    rc.right = rc.left + BoxW;
    

    // game screen
    RectSet(&pDeskInfo->rcPaint, DrawBorder, pDisplay->width-DrawBorder, DrawBorder, rc.top - DrawBorder-50);
    
    for(i=0;i<(BTN_NUM - 3);i++){
        RectCopy(&pDeskInfo->szPalette[i].rc, &rc);
        pDeskInfo->szPalette[i].color = szPalette[i];
        RectOffset(&rc, BoxW+GapW, 0);

    }

	//set dimension to the full screen reset
	rc.top = pDisplay->height - 5;
	rcScreen.bottom = rc.top * 2;
	rc.left = pDisplay->width - 5;
	rc.right = pDisplay->width * 2;


    //create the full screen reset button for when the player loses
    RectCopy(&pDeskInfo->szPalette[8].rc, &rc);
    pDeskInfo->szPalette[8].color = szPalette[8];
   // pDeskInfo->szPalette[BTN_CLEAR].rc.left -= ClearExtraW;
   // pDeskInfo->Paint_Index = BTN_BLUE;
}

int GUI_CheckButton(DESK_INFO *pDeskInfo, POINT *pt){
    int ButtonId = BTN_NONE;
    int i;

    for(i=0;i<BTN_NUM && (ButtonId == BTN_NONE);i++){
        if (IsPtInRect(pt, &pDeskInfo->szPalette[i].rc))
            ButtonId = i;

    }
   // printf("button number: %d\r\n", ButtonId);
    return ButtonId;
}

void GUI_DeskDraw(alt_video_display *pDisplay, DESK_INFO *pDeskInfo){
    int i, active;
    RECT rc;
    // show text
  //  vid_print_string_alpha(pDeskInfo->rcPaint.left, pDeskInfo->szPalette[0].rc.top, BLUE_24, BLACK_24, tahomabold_20, pDisplay, "Terasic");
  //  vid_print_string_alpha(pDeskInfo->rcPaint.left, pDeskInfo->szPalette[0].rc.top+22, BLUE_24, BLACK_24, tahomabold_20, pDisplay, "Touch");

    // draw game region
    RectCopy(&rc, &pDeskInfo->rcPaint);
    vid_draw_box (rc.left + 5, rc.top + 5, rc.right - 5, rc.bottom, WHITE_24, DO_NOT_FILL, pDisplay);
    

    // draw directional buttons
	//active = pDeskInfo->Paint_Index;
    for(i=0;i<BTN_NUM;i++){
        RectCopy(&rc, &(pDeskInfo->szPalette[i].rc));
        switch(i){
			case 0:
				 vid_draw_box (rc.left, rc.top, rc.right, rc.bottom, BLUE_24, DO_NOT_FILL, pDisplay);
				 vid_print_string_alpha(rc.left + 13, rc.top+(RectHeight(&rc)-22)/2, BLUE_24, BLACK_24, tahomabold_20, pDisplay, "L");
				 break;
			case 1:
				 vid_draw_box (rc.left, rc.top, rc.right, rc.bottom, BLUE_24, DO_NOT_FILL, pDisplay);
				 vid_print_string_alpha(rc.left + 13, rc.top+(RectHeight(&rc)-22)/2, BLUE_24, BLACK_24, tahomabold_20, pDisplay, "D");
				 break;
			case 2:
				 vid_draw_box (rc.left, rc.top, rc.right, rc.bottom,BLUE_24, DO_NOT_FILL, pDisplay);
				 vid_print_string_alpha(rc.left + 13, rc.top+(RectHeight(&rc)-22)/2, BLUE_24, BLACK_24, tahomabold_20, pDisplay, "U");
				 break;
			case 3:
				 vid_draw_box (rc.left, rc.top, rc.right, rc.bottom, BLUE_24, DO_NOT_FILL, pDisplay);
				 vid_print_string_alpha(rc.left + 13, rc.top+(RectHeight(&rc)-22)/2, BLUE_24, BLACK_24, tahomabold_20, pDisplay, "R");
				 break;
        }
    }


}

//quick function to initialize arrays to 0
void reset( int *array, int size) {
   memset(array,0,size * sizeof(*array));
}

//paints each 10x10 snake block and gives it a outline
void paint_Cell(int head_X, int head_Y, alt_video_display *pDisplay){

	//create box
	vid_draw_box(head_X, head_Y, head_X + 10, head_Y + 10, GREEN_24, DO_FILL, pDisplay);
	//usleep(100);
	//outline
	vid_draw_box(head_X , head_Y, head_X + 10, head_Y +10, YELLOW_24, DO_NOT_FILL, pDisplay);

}

//clear blacks out the last block in the snake
void clear_Cell(int head_X, int head_Y, alt_video_display *pDisplay){

	vid_draw_box(head_X , head_Y, head_X + 10, head_Y +10, BLACK_24, DO_FILL, pDisplay);
	//usleep(10);

}

//display food
void paint_Food(int food_X, int food_Y, alt_video_display *pDisplay){

	vid_draw_box(food_X, food_Y, food_X + 10, food_Y +10, RED_24, DO_FILL, pDisplay);

}

// function to update the head locaiton and pass back to gui to print
HEAD_LOCATION get_Current_Locaiton_And_Increment(DIRECTION current_Direction,
												HEAD_LOCATION headLocation, alt_video_display *pDisplay, int offset){
	int head_X = headLocation.head_X;
	int head_Y = headLocation.head_Y;

	if(current_Direction == RIGHT){
		head_X = head_X + offset;
		if(head_X > (pDisplay->width) - 20){		//make sure your staying within the bounds
			head_X = 10;
		}
	}
	else if(current_Direction == LEFT){
		head_X = head_X - offset;
		if(head_X < 10){
			head_X = (pDisplay->width) - 20;		//make sure your staying within the bounds
		}
	}
	else if(current_Direction == UP){
		head_Y = head_Y - offset;
		if(head_Y < 10){
			head_Y = (pDisplay->height) - 110;		//make sure your staying within the bounds
		}
	}
	else if(current_Direction == DOWN){
		head_Y = head_Y + offset;
		if(head_Y > (pDisplay->height) - 110){		//make sure your staying within the bounds
			head_Y = 10;
		}
	}
	headLocation.head_X = head_X;
	headLocation.head_Y = head_Y;
	return headLocation;
}

//initialize the head location struct
HEAD_LOCATION initializeHead(int X,int Y){

	HEAD_LOCATION headLocation;
	headLocation.head_X = X;
	headLocation.head_Y = Y;
	return headLocation;

}

//initialize the food location struct
FOOD_LOCATION initializeFood(int food_X, int food_Y){

	FOOD_LOCATION foodLocation;
	foodLocation.food_X = food_X;
	foodLocation.food_Y = food_Y;
	return foodLocation;

}

//get new food location
FOOD_LOCATION set_XY_Food(int gridFill_Y[], int gridFill_X[], int snakeSize, FOOD_LOCATION foodLocation){

	int counter;
	int flag = 0;

	//a default position
	foodLocation.food_Y = 10;
	foodLocation.food_X = 20;

	while(1){
		foodLocation.food_Y = (rand() % 20) * 10;
		foodLocation.food_X = (rand() % 20) * 10;
		for(counter = 0; counter < snakeSize; counter++){

			//make sure it isn't located where the snake is
			if((gridFill_X[counter] == foodLocation.food_X)&&(gridFill_Y[counter] == foodLocation.food_Y)){
				flag++;
				break;
			}

			//make sure the food is in the game screen
			else if((foodLocation.food_X < 10) || (foodLocation.food_X > 210)||(foodLocation.food_Y < 10) || (foodLocation.food_Y > 210)){
				flag++;
				break;
			}
		}

		if(flag > 0){
			flag = 0;
		}

		else{
			return foodLocation;	//success now go display the food
		}
	}
}


//game over and restart screen
void game_Over(int score, alt_video_display *pDisplay, TOUCH_HANDLE *pTouch){

	int x_text, y_text, counter;
	char char_Score[4] = {'0', '0', '0', '\0'};
	for(counter = 0; counter < 3; counter++){
		switch(counter){
			case 0:

				char_Score[counter] = (score / 100) + 48;
				score = score - (score/100)*100;
				break;
			case 1:
				char_Score[counter] = (score / 10) + 48;
				score = score - (score/10)*10;
				break;
			case 2:
				char_Score[counter] = (score / 1) + 48;
				break;
		}
	}
	Touch_EmptyFifo(pTouch);	//empty the fifo used for touch screen handling
	vid_clean_screen(pDisplay, RED_24);
	usleep(1*50*1000);
	x_text = 20;
	y_text = 60;
	vid_clean_screen(pDisplay, BLACK_24);
	vid_print_string_alpha(x_text, y_text, BLUE_24, BLACK_24, tahomabold_20, pDisplay, "I told you");
	vid_print_string_alpha(x_text, y_text + 30, BLUE_24, BLACK_24, tahomabold_20, pDisplay, "not to eat yourself!");
	usleep(1*1000*1000);
	vid_clean_screen(pDisplay, BLACK_24);
	vid_print_string_alpha(x_text, y_text, BLUE_24, BLACK_24, tahomabold_20, pDisplay, "SCORE:");
	vid_print_string_alpha(x_text + 40, y_text+ 40, BLUE_24, BLACK_24, tahomabold_20, pDisplay, char_Score);
	vid_print_string_alpha(x_text , y_text + 120 , BLUE_24, BLACK_24, tahomabold_20, pDisplay, "touch to try again" );


}

void print_Score(int score, alt_video_display *pDisplay ){
	int counterScore;
	char char_Score[4] = {'0', '0', '0', '\0'};
	for(counterScore = 0; counterScore < 3; counterScore++){
		switch(counterScore){
			case 0:
				char_Score[counterScore] = (score / 100) + 48;
				score = score - (score/100)*100;
				break;
			case 1:
				char_Score[counterScore] = (score / 10) + 48;
				score = score - (score/10)*10;
				break;
			case 2:
				char_Score[counterScore] = (score / 1) + 48;
				break;
		}
	}

	vid_print_string_alpha(140, 240, BLUE_24, BLACK_24, tahomabold_20, pDisplay, char_Score);
}

//main gui loop to display snake
void GUI(alt_video_display *pDisplay, TOUCH_HANDLE *pTouch){
    //define and initialize
    DESK_INFO DeskInfo;						//the screen info
    DIRECTION current_Direction = RIGHT;	//initial direction is going right

    //for touch points
    int X, Y;
    POINT Pt;
    RECT rcTouch;
    int ButtonId;
    Touch_EmptyFifo(pTouch);	//empty the fifo used for touch screen handling

    //using rand to get the food position
    time_t t = 0;
    srand((unsigned) time(&t));


   //int LedMask = 1;						//used to debug touch
    int offset = 10;						//snake block is 10x10 pixels

    //snake's length start score =   score - snakeSize
    int snakeSize = 10;
    int score = 0;

    //initial position of the snake's head
    int head_Y = pDisplay->height / 2 - 10;
    int head_X = pDisplay->width / 2 - 60;

    //a generic iterator
    int jj = 0;

    //initialize the head and food locations
    HEAD_LOCATION headLocation = initializeHead(head_X, head_Y);
    FOOD_LOCATION foodLocation = initializeFood(60, 60);

    //used two fixed length arrays to store the x and y coordinates for the snake
    int gridFill_X[300];
    int gridFill_Y[300];
    reset(gridFill_X, 300);
    reset(gridFill_Y, 300);
    //bool restart_Touch = FALSE;

    // start screen

    GUI_ShowWelcome(pDisplay);
    vid_clean_screen(pDisplay, BLACK_24);
    usleep(100);
    vid_print_string_alpha(20, 240, BLUE_24, BLACK_24, tahomabold_20, pDisplay, "SCORE:");
    usleep(100);
    paint_Food(foodLocation.food_X, foodLocation.food_Y, pDisplay);
    print_Score(score, pDisplay);
    usleep(100);
    //button initialization
    GUI_DeskInit(pDisplay, &DeskInfo);
    GUI_DeskDraw(pDisplay, &DeskInfo);
    RectCopy(&rcTouch, &DeskInfo.rcPaint);
   // colorPen = DeskInfo.szPalette[DeskInfo.Paint_Index].color;
   // PtSet(&ptGesture, DeskInfo.szPalette[BTN_GESTRUE].rc.left+5, DeskInfo.szPalette[BTN_GESTRUE].rc.top+5);

    //display the first food item




    //game loop
    while(1){

    	if((head_X == foodLocation.food_X) && (head_Y == foodLocation.food_Y)){
			//needNewFood = 'y';
			foodLocation = set_XY_Food(gridFill_Y, gridFill_X, snakeSize, foodLocation);
			paint_Food(foodLocation.food_X, foodLocation.food_Y, pDisplay);
			snakeSize++;
			score++;
			print_Score(score, pDisplay);
		}

    	headLocation = get_Current_Locaiton_And_Increment(current_Direction, headLocation, pDisplay, offset);
		head_X = headLocation.head_X;
		head_Y = headLocation.head_Y;
		for(jj = 0; jj< snakeSize; jj++){
			if((head_X == gridFill_X[jj]) && (head_Y == gridFill_Y[jj])){
				//game over
				game_Over(score, pDisplay, pTouch);
				while(1){
					if (Touch_GetXY(pTouch, &X, &Y)){

						PtSet(&Pt, X, Y);
						ButtonId = GUI_CheckButton(&DeskInfo, &Pt);
						if (ButtonId){
							//GUI_DeskDraw(pDisplay, &DeskInfo);
							GUI(pDisplay, pTouch);

						}
					} // ends the touch screen handling
				}
			}
		}

		gridFill_X[snakeSize] = head_X;
		gridFill_Y[snakeSize] = head_Y;

		if(snakeSize < 2){
			for(jj = snakeSize; jj > 0; jj--){
				if(jj == snakeSize){
					clear_Cell(gridFill_X[0],gridFill_Y[0], pDisplay);
				}
				paint_Cell(gridFill_X[jj],gridFill_Y[jj], pDisplay);
			}
			for(jj = 0; jj < snakeSize ; jj++){
				gridFill_X[jj] = gridFill_X[jj + 1];
				gridFill_Y[jj] = gridFill_Y[jj + 1];
			}
		}
		else{
			clear_Cell(gridFill_X[0],gridFill_Y[0], pDisplay);
			paint_Cell(gridFill_X[snakeSize],gridFill_Y[snakeSize], pDisplay);
			for(jj = 0; jj < snakeSize ; jj++){
				gridFill_X[jj] = gridFill_X[jj + 1];
				gridFill_Y[jj] = gridFill_Y[jj + 1];
			}

		}

		usleep(90*1000);
		if (Touch_GetXY(pTouch, &X, &Y)){
					//
		//			IOWR(LED_BASE, 0x00, LedMask);
		//			LedMask <<= 1;
		//				if (LedMask > 255)
		//					LedMask = 0x01;

					//printf("x=%d, y=%d\r\n", X,Y);
					PtSet(&Pt, X, Y);
					ButtonId = GUI_CheckButton(&DeskInfo, &Pt);
					if (ButtonId != BTN_NONE){
						DeskInfo.Paint_Index = ButtonId;
						//colorPen = DeskInfo.szPalette[DeskInfo.Paint_Index].color;
						switch(DeskInfo.Paint_Index){
							case 0:
								if(current_Direction != RIGHT){
									current_Direction = LEFT;
								}
								break;
							case 1:
								if(current_Direction != UP){
									current_Direction = DOWN;
								}
								break;
							case 2:
								if(current_Direction != DOWN){
									current_Direction = UP;
								}
								break;
							case 3:
								if(current_Direction != LEFT){
									current_Direction = RIGHT;
								}
								break;
						}
						//GUI_DeskDraw(pDisplay, &DeskInfo);
						Touch_EmptyFifo(pTouch);	//empty the fifo used for touch screen handling
					}
				} // ends the touch screen handling
	} // end the main game while
}	//end main gui


//void GUI_ShowInfo(alt_video_display *pDisplay, char *pText){
//    static int x=0,y=100;
//   // vid_clean_screen(pReader, BLACK_24);
//    vid_print_string_alpha(x, y, BLUE_24, BLACK_24, tahomabold_20, pDisplay, pText);
// //   VIPFR_ActiveDrawFrame(pReader);
//}
//
//void GUI_ShowTouchPoint(alt_video_display *pDisplay, int X, int Y, int color){
//    vid_draw_circle(X, Y, 10, color, DO_FILL, pDisplay);
//   // VIPFR_ActiveDrawFrame(pReader);
//}

